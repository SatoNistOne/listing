class ExplicitCast {
    
    public static void main(String[] args) {
        
        long l = 10;
        double d = l; 
        l = (long) d; 
        
    }
    
}