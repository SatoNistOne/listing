public class CharArithDemo {
    
    public static void main(String[] args) {
        
        char ch;
        
        ch = 'L';
        System.out.println("ch равно " + ch);
        
        ch++;
        System.out.println("значение ch изменилось на " + ch);
        
        ch = 'Д';
        ch--;
        System.out.println("значение ch снова изменилось и равно " + ch);
        
    }
    
}