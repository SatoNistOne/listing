public class AssignExample {
    
    public static void main(String[] args) {
        
        int var1;
        int var2;
        
        var1 = 4096;
        var2 = var1 / 4;
        
        System.out.println("var1 = " + var1);
        System.out.println("var2 = var1 / 4 = " + var2);
        
    }
    
}