import java.io.PrintStream;
public class ShortcutOutDemo {

    private static PrintStream out = System.out;

    public static void main(String[] args) {

        out.println("Пример сокращенной записи команды вывода на консоль...");
        
    } 
    
} 